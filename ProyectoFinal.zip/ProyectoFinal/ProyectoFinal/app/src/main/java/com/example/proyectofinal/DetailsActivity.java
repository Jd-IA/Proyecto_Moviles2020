package com.example.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {
    //Elementos necesarias.
    private TextView asunto, detalle;
    private Button regresar;
    private String asuntoRec, detalleRec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        //Vinculamos los elementos al diseño
        asunto = findViewById(R.id.asunto_vista);
        detalle = findViewById(R.id.detaille_vista);
        regresar = findViewById(R.id.back_list);
        //Recuperamos la información de la notificación
        asuntoRec = getIntent().getStringExtra("asunto");
        detalleRec = getIntent().getStringExtra("detalles");
        //Seteamos lo recuperado en sus debidos campos
        if(asuntoRec == null | asuntoRec == ""){
            asunto.setText("Sin Asunto");
        } //En caso de no tener un asunto
        else{
            asunto.setText(asuntoRec);
        }
        if(detalleRec == null | detalleRec == ""){
            detalle.setText("Sin Detalle");
        } //En caso de no tener detalle
        else{
            detalle.setText(detalleRec);
        }
        //OnClickListener del botón regresar
        regresar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent in = new Intent(DetailsActivity.this, MenuActivity.class);
        startActivity(in);
        finish();
    }
}