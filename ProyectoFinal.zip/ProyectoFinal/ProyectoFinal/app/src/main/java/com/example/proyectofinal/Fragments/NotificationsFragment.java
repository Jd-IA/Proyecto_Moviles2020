package com.example.proyectofinal.Fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.proyectofinal.DetailsActivity;
import com.example.proyectofinal.ListNotificationsAdapter;
import com.example.proyectofinal.Notification;
import com.example.proyectofinal.R;

import java.util.ArrayList;

public class NotificationsFragment extends Fragment implements AdapterView.OnItemClickListener {
    private ListView listView;
    private ArrayList<Notification> notifications;
    private ListNotificationsAdapter lna;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.notifications_fragment, container,false);
        listView = view.findViewById(R.id.listView);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        notifications = new ArrayList<>();
        //Recuperamos los items de la lista
        recuperarItems();
        //Creamos el adaptador de lista
        lna = new ListNotificationsAdapter(getContext().getApplicationContext(),
                R.layout.list_notifications_item, notifications);
        //Seteamos el adaptador a la lista
        listView.setAdapter(lna);
        //Seteamos el OnClickListener
        listView.setOnItemClickListener(this);
    }

    private void recuperarItems() {
        notifications.add(new Notification(0, "Prueba", "Esta es la prueba 1 de" +
                " la vista de una notificación"));
        notifications.add(new Notification(1, "", ""));
        notifications.add(new Notification(2, null, null));
        notifications.add(new Notification(3, "Becas", "Ya ha sido aprobado para " +
                "recibir su beca en este periodoo 2021-1"));
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Notification aux = (Notification) lna.getItem(position);

        Intent in = new Intent(getContext().getApplicationContext(), DetailsActivity.class);
        in.putExtra("asunto", aux.getAsunto());
        in.putExtra("detalles", aux.getInfo());
        startActivity(in);
        getActivity().finish();
    }
}
