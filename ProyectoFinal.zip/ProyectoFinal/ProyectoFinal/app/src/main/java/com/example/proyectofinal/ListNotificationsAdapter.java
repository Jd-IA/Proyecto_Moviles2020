package com.example.proyectofinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ListNotificationsAdapter extends BaseAdapter {
    private ArrayList<Notification> notifications;
    private Context c;
    private int diseno;

    public ListNotificationsAdapter(Context c, int diseno, ArrayList<Notification> notifications) {
        this.notifications = notifications;
        this.c = c;
        this.diseno = diseno;
    }

    @Override
    public int getCount() {
        return notifications.size();
    }

    @Override
    public Object getItem(int position) {
        return notifications.get(position);
    }

    @Override
    public long getItemId(int position) {
        return notifications.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if(v == null){
            LayoutInflater lif = LayoutInflater.from(c);
            v = lif.inflate(diseno, null);
        }
        TextView tv = v.findViewById(R.id.asunto_notification);
        if(notifications.get(position).getAsunto() == "" |
           notifications.get(position).getAsunto() == null){
            tv.setText("Sin Asunto");
        }
        else{
            tv.setText(notifications.get(position).getAsunto());
        }

        return v;
    }
}
