package com.example.proyectofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.proyectofinal.Fragments.NotificationsFragment;
import com.google.android.material.navigation.NavigationView;

public class MenuActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener{
    //Menu
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private Toolbar toolbar;
    private NavigationView navigationView;
    //Fragment
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        //Menu
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
            //Listener Nav
        navigationView.setNavigationItemSelectedListener(this);
            //Action bar
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.open, R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();
        //Cargar Fragment
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, new NotificationsFragment());
        fragmentTransaction.commit();
        //Algunas cosas extras
        recuperarPreferencias();
    }
    //Recupera la información del Login y lo aplica al header del menu
    private void recuperarPreferencias() {
        SharedPreferences preferences = getSharedPreferences("credenciales",
                Context.MODE_PRIVATE);
        String tip = preferences.getString("tipo", "Sin Tipo");
        String nom = preferences.getString("info", "Sin Info");
        //Setea la información en el header del menu
        View header = navigationView.getHeaderView(0);
        ((TextView) header.findViewById(R.id.nombre_inicio)).setText(nom);
        ((TextView) header.findViewById(R.id.tipo_inicio)).setText(tip);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        //Cierra automaticamente el menu al hacer click en un item
        drawerLayout.closeDrawer(GravityCompat.START);
        if(item.getItemId() == R.id.home){
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container, new NotificationsFragment());
            fragmentTransaction.commit();
        }
        else if(item.getItemId() == R.id.exit){
            Intent in = new Intent(MenuActivity.this, LoginActivity.class);
            startActivity(in);
            overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            finish();

            SharedPreferences preferences = getSharedPreferences("credenciales",
                    Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("logueado", "no");
            editor.commit();
        }
        return false;
    }
}