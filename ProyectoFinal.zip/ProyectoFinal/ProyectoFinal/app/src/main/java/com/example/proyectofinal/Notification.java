package com.example.proyectofinal;

public class Notification {
    private String asunto, info;
    private int id;
    public Notification(int id, String asunto, String info){
        this.id = id;
        this.asunto = asunto;
        this.info = info;
    }
    //Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
