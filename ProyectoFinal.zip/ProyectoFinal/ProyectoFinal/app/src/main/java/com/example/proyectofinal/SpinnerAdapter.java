package com.example.proyectofinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class SpinnerAdapter extends BaseAdapter {
    //Variables necesarias del Spinner
    private ArrayList<String> tipos;
    private int diseno;
    private Context c;

    public SpinnerAdapter(Context c, int diseno, ArrayList<String> tipos) {
        this.tipos = tipos;
        this.diseno = diseno;
        this.c = c;
    }

    @Override
    public boolean isEnabled(int position) {
        if(position == 0){
            return false;
        }
        else{
            return true;
        }
    }
    @Override
    public int getCount() {
        return tipos.size();
    }
    @Override
    public Object getItem(int position) {
        return tipos.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if(v == null){
            LayoutInflater lf = LayoutInflater.from(c);
            v = lf.inflate(diseno, null);
        }
        TextView tv = v.findViewById(R.id.select_login);
        tv.setText(tipos.get(position));

        return v;
    }
}
